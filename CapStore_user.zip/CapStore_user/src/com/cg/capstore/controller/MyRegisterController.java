package com.cg.capstore.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.capstore.dto.Customer;
import com.cg.capstore.dto.Merchant;
import com.cg.capstore.service.ICapStoreService;



@Controller
public class MyRegisterController {
	@Autowired
	ICapStoreService service; 
	@RequestMapping(value="all")
public String redirect()
{
	return "login";
}
	
	@RequestMapping(value="registration")
	public String AddCustomer(Model model,@ModelAttribute("cust") Customer customer)
	{
		return "registration";
		}
	@RequestMapping(value="save",method=RequestMethod.POST)
	public String insertCustomer(@Valid@ModelAttribute("cust") Customer customer,BindingResult result,Model model)
	{String email=null;
	if(result.hasErrors())
	{
		return "registration";
	}
	else{
	
		email=service.addCustomer(customer);
	model.addAttribute("cust", email);
		return "custRegSuccess";
	}}
	
	@RequestMapping(value="merchantLogin")
	public String MoveToMerchantLogin()
	{
		return "merchantLogin";
		}
	@RequestMapping(value="merchantReg")
	public String AddMerchant(Model model,@ModelAttribute("merchant") Merchant merchant)
	{
		return "merchantReg";
		}
	@RequestMapping(value="saveMerchant",method=RequestMethod.POST)
	public String insertMerchant(@Valid@ModelAttribute("merchant") Merchant merchant,BindingResult result,Model model)
	{String email=null;
	if(result.hasErrors())
	{
		return "merchantReg";
	}
	else{
	
		email=service.addMerchant(merchant);
	model.addAttribute("merchant", email);
		return "merchantSuccess";
	}}
	@RequestMapping(value="adminLogin")
	public String AdminLogin()
	{
		return "adminLogin";
	}
	@RequestMapping(value="retrieve_customer")
public String fetchCustomer(@ModelAttribute("data") Customer customer,BindingResult result,Model model,@RequestParam("email") String emailId,
		@RequestParam("password") String password)
{
		Customer customere = service.fetchCustomerId(customer.getEmail());
		
		if(customere.getEmail().equals(emailId) && customere.getPassword().equals(password))
		{model.addAttribute("email",emailId);
			return "home";
		}
		else if(!customere.getEmail().equals(emailId))
		{model.addAttribute("error","invalid mail id");
			return "login";
		}
		else
		{model.addAttribute("error","invalid credential");
		return "login";}
}
	
	@RequestMapping(value="retrieve_merchant")
public String fetchMerchant(@ModelAttribute("dataMerchant") Merchant merchant,BindingResult result,Model model,@RequestParam("email") String emailId,
		@RequestParam("password") String password)
{
Merchant customere = service.fetchMerchantId(merchant.getEmail());
if(customere.getEmail().equals(emailId) && customere.getPassword().equals(password))
	{model.addAttribute("email",emailId);
		return "home";
	}
	else
	{model.addAttribute("error","invalid credentials");
		return "merchantLogin";
	}
}
}
